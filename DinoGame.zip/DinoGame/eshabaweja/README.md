# The Dinosaur Game

This is a simple version of the famous hidden game from Chrome offline mode.
Feel free to make it better in any way possible!

![Screenshot of game](assets/dino-ss.png)


# SnakeGame

Snake game built using HTML, CSS and JS.

# Installation

Run with live server to run SnakeGame

```bash
Open HTML file and right click on the editor on Open with Live Server.
```

## Usage

Use arrow keys to control tge snake head.
